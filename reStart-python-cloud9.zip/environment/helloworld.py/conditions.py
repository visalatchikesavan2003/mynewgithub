#userReply = input("Do you need to ship a package? ( no) ")


#if userReply == "no":
    #print("We can help you ship that package!")


#else:
    #print("Please come back when you need to ship a package. Thank you.")
    
userReply = input("Would you like to buy stamps, buy an envelope, or make a copy? ( stamps ) ")
if userReply == "stamps":
    print("We have many stamp designs to choose from.")