print("Python has three numeric types: int, float, bool and complex")
myvalue=true
print(true)
print(type(true))
print(str(true) + " is of the data type " + str(type(true)))
